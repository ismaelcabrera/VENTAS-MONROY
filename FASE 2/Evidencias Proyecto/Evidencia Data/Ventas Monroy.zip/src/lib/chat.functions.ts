import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const SYSTEM_PROMPT = `Eres "Moni", el asistente virtual de SERVICIO DE VENTAS MONROY, una tienda de barrio chilena que vende aceitunas, maní y confites con despacho a domicilio.

Catálogo actual (precios en pesos chilenos):
- Aceitunas Verdes con Hierbas — $4.990 / 500 g — aliñadas con romero y ajo.
- Aceitunas Negras Kalamata — $5.490 / 500 g — en aceite de oliva.
- Maní Salado Tostado — $2.990 / 500 g — tostado en casa.
- Maní Confitado al Caramelo — $3.490 / 400 g — bañado en caramelo.
- Mix de Confites Surtidos — $3.990 / 500 g — gomitas y grageas.
- Almendras con Chocolate — $5.990 / 400 g — chocolate amargo con cacao.

Información de la tienda:
- Despacho el mismo día dentro del barrio; pedidos antes de las 18:00 llegan ese día.
- Retiro en tienda sin costo.
- Envío gratis en pedidos sobre $20.000; si no, el despacho cuesta $1.990.
- Pagos: efectivo, tarjeta y transferencia al recibir.
- Horario: lunes a sábado de 9:00 a 20:00.

Reglas:
- Responde siempre en español, con tono cercano, amable y breve (máximo 3-4 frases).
- Si preguntan por algo fuera del catálogo o de la tienda, responde con amabilidad que solo puedes ayudar con la tienda.
- No inventes productos, precios ni promociones que no estén en esta lista.
- Puedes sugerir productos según lo que pida el cliente (algo dulce, salado, para compartir, etc.).`;

const FALLBACK =
  "Ups, tuve un problema para responder. ¿Puedes intentarlo de nuevo?";

export const sendChatMessage = createServerFn({ method: "POST" })
  .inputValidator((data) =>
    z
      .object({
        messages: z
          .array(
            z.object({
              role: z.enum(["user", "assistant"]),
              content: z.string().min(1).max(2000),
            }),
          )
          .min(1)
          .max(40),
      })
      .parse(data),
  )
  .handler(async ({ data }) => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) {
      return {
        reply:
          "Lo siento, el asistente no está disponible en este momento. Intenta más tarde.",
      };
    }

    const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Lovable-API-Key": apiKey,
        "X-Lovable-AIG-SDK": "fetch",
      },
      body: JSON.stringify({
        model: "openai/gpt-6-astra",
        instructions: SYSTEM_PROMPT,
        input: data.messages.map((m) => ({
          role: m.role,
          content: m.content,
        })),
        stream: true,
        store: false,
        reasoning: { effort: "low", summary: "auto" },
        include: ["reasoning.encrypted_content"],
      }),
    });

    if (!res.ok || !res.body) {
      return { reply: FALLBACK };
    }

    // Consume el stream SSE y acumula el texto final
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let reply = "";

    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const events = buffer.split("\n\n");
      buffer = events.pop() ?? "";
      for (const event of events) {
        for (const line of event.split("\n")) {
          if (!line.startsWith("data:")) continue;
          const payload = line.slice(5).trim();
          if (!payload || payload === "[DONE]") continue;
          try {
            const json = JSON.parse(payload) as {
              type?: string;
              delta?: string;
            };
            if (json.type === "response.output_text.delta" && json.delta) {
              reply += json.delta;
            }
          } catch {
            /* frame incompleto */
          }
        }
      }
    }

    return { reply: reply.trim() || FALLBACK };
  });

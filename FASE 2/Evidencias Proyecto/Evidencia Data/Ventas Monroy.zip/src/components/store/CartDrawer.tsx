import { useState } from "react";
import { CheckCircle2, Minus, Plus, Trash2, X } from "lucide-react";
import { formatCLP } from "@/lib/products";
import { useCart } from "@/lib/cart";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";

const FREE_SHIPPING = 25000;

export function CartDrawer() {
  const { lines, total, isOpen, setOpen, setQty, remove, clear } = useCart();
  const { user, setLoginOpen } = useAuth();
  const [checkout, setCheckout] = useState(false);
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [orderId, setOrderId] = useState<string | null>(null);

  if (!isOpen) return null;

  const shipping = total === 0 || total >= FREE_SHIPPING ? 0 : 2990;

  const placeOrder = async () => {
    if (!user) return setLoginOpen(true);
    setBusy(true);
    setError(null);
    const { data, error: orderError } = await supabase
      .from("orders")
      .insert({
        user_id: user.id,
        address: address.trim(),
        phone: phone.trim() || null,
        notes: notes.trim() || null,
        subtotal: total,
        shipping,
        total: total + shipping,
      })
      .select("id")
      .single();
    if (orderError || !data) {
      setError("No pudimos registrar tu pedido. Intenta nuevamente.");
      setBusy(false);
      return;
    }
    const { error: itemsError } = await supabase.from("order_items").insert(
      lines.map(({ product, qty }) => ({
        order_id: data.id,
        product_id: product.id,
        product_name: product.name,
        unit_price: product.price,
        qty,
      })),
    );
    if (itemsError) {
      setError("Tu pedido se creó pero faltaron productos. Contáctanos.");
      setBusy(false);
      return;
    }
    setOrderId(data.id);
    clear();
    setCheckout(false);
    setAddress("");
    setPhone("");
    setNotes("");
    setBusy(false);
  };

  return (
    <div className="fixed inset-0 z-50">
      <button
        aria-label="Cerrar carrito"
        className="absolute inset-0 bg-foreground/40 backdrop-blur-sm"
        onClick={() => setOpen(false)}
      />
      <aside className="absolute right-0 top-0 flex h-full w-full max-w-md flex-col bg-background shadow-2xl">
        <div className="flex items-center justify-between border-b border-primary/10 px-5 py-4">
          <div>
            <p className="font-hand text-2xl leading-none text-primary">
              Tu carrito
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              {lines.length === 0
                ? "Todavía está vacío"
                : `${lines.length} producto${lines.length > 1 ? "s" : ""}`}
            </p>
          </div>
          <button
            onClick={() => setOpen(false)}
            className="grid size-10 place-items-center rounded-full bg-secondary transition-transform hover:scale-105"
            aria-label="Cerrar"
          >
            <X className="size-4" />
          </button>
        </div>

        <div className="flex-1 space-y-3 overflow-y-auto px-5 py-4">
          {orderId && (
            <div className="rounded-2xl bg-primary/10 p-5 text-center ring-1 ring-primary/20">
              <CheckCircle2 className="mx-auto size-8 text-primary" />
              <p className="mt-2 font-hand text-2xl text-primary">
                ¡Pedido recibido!
              </p>
              <p className="mt-1 text-sm text-muted-foreground">
                Nº {orderId.slice(0, 8).toUpperCase()} · te contactaremos para
                coordinar la entrega.
              </p>
            </div>
          )}
          {lines.length === 0 && !orderId && (
            <p className="rounded-2xl bg-card p-6 text-center text-sm text-muted-foreground ring-1 ring-primary/10">
              Agrega aceitunas, maní o confites desde el catálogo. 🫒
            </p>
          )}
          {lines.map(({ product, qty }) => (
            <div
              key={product.id}
              className="flex items-center gap-3 rounded-2xl bg-card p-3 ring-1 ring-primary/10"
            >
              <img
                src={product.image}
                alt={product.name}
                width={1024}
                height={1024}
                loading="lazy"
                className="size-16 shrink-0 rounded-xl object-cover"
              />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{product.name}</p>
                <p className="text-xs text-muted-foreground">
                  {formatCLP(product.price)} · {product.unit}
                </p>
                <div className="mt-2 flex items-center gap-2">
                  <button
                    onClick={() => setQty(product.id, qty - 1)}
                    className="grid size-7 place-items-center rounded-full bg-secondary"
                    aria-label="Quitar uno"
                  >
                    <Minus className="size-3.5" />
                  </button>
                  <span className="w-6 text-center text-sm font-semibold">
                    {qty}
                  </span>
                  <button
                    onClick={() => setQty(product.id, qty + 1)}
                    className="grid size-7 place-items-center rounded-full bg-secondary"
                    aria-label="Agregar uno"
                  >
                    <Plus className="size-3.5" />
                  </button>
                </div>
              </div>
              <div className="flex shrink-0 flex-col items-end gap-2">
                <span className="font-display text-sm font-bold">
                  {formatCLP(product.price * qty)}
                </span>
                <button
                  onClick={() => remove(product.id)}
                  className="grid size-7 place-items-center rounded-full text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
                  aria-label={`Eliminar ${product.name}`}
                >
                  <Trash2 className="size-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {lines.length > 0 && (
          <div className="border-t border-primary/10 px-5 py-4">
            <div className="space-y-1.5 text-sm">
              <div className="flex justify-between text-muted-foreground">
                <span>Subtotal</span>
                <span>{formatCLP(total)}</span>
              </div>
              <div className="flex justify-between text-muted-foreground">
                <span>Envío</span>
                <span>{shipping === 0 ? "Gratis" : formatCLP(shipping)}</span>
              </div>
              <div className="flex justify-between pt-1 font-display text-lg font-semibold">
                <span>Total</span>
                <span>{formatCLP(total + shipping)}</span>
              </div>
            </div>
            {checkout && user && (
              <div className="mt-4 space-y-2">
                <input
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="h-11 w-full rounded-full bg-card px-4 text-sm outline-none ring-1 ring-input focus:ring-2 focus:ring-ring"
                  placeholder="Dirección de entrega"
                />
                <input
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="h-11 w-full rounded-full bg-card px-4 text-sm outline-none ring-1 ring-input focus:ring-2 focus:ring-ring"
                  placeholder="Teléfono de contacto"
                />
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  className="w-full rounded-2xl bg-card px-4 py-3 text-sm outline-none ring-1 ring-input focus:ring-2 focus:ring-ring"
                  placeholder="Comentarios (opcional)"
                />
              </div>
            )}
            {error && (
              <p className="mt-3 rounded-2xl bg-destructive/10 px-4 py-2 text-xs text-destructive">
                {error}
              </p>
            )}
            <button
              onClick={() => {
                setOrderId(null);
                if (!user) return setLoginOpen(true);
                if (!checkout) return setCheckout(true);
                if (address.trim().length < 5)
                  return setError("Ingresa tu dirección de entrega.");
                void placeOrder();
              }}
              disabled={busy}
              className="mt-4 w-full rounded-full bg-honey py-3.5 text-sm font-bold text-honey-foreground shadow-lg shadow-honey/40 transition-transform hover:scale-[1.02] active:scale-95 disabled:opacity-60"
            >
              {!user
                ? "Inicia sesión para finalizar"
                : busy
                  ? "Enviando pedido…"
                  : checkout
                    ? "Confirmar pedido"
                    : "Finalizar compra"}
            </button>
            <p className="mt-2 text-center text-xs text-muted-foreground">
              Envío gratis sobre {formatCLP(FREE_SHIPPING)}
            </p>
          </div>
        )}
      </aside>
    </div>
  );
}

# Tasks
- [x] Create visual administrator with overview, inventory, movements and orders using isolated demo data.
- [x] Verify navigation, demo controls and small-screen layout.
- [x] Chatbot "Moni" on the main page (floating widget + AI via Lovable gateway).